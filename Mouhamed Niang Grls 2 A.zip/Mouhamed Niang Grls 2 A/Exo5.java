import java.util.Scanner;
class Exo5{
    public static void main(String[] args)
    {
        Scanner art = new Scanner(System.in);
        /*
            Saisir une serie de n nombre positif puis determiner 
            1)la valeur min et la valeur max
            2)les 2 valeur min et les 2 valeur max
            3)la somme des valeurs premiers
            4)le produit des valeurs parfaits
            5)La valeur min premier et la valeur max parfaite 
        */
        int x=0;
        int y=0;
        do{
            System.out.print("Entrer une valeur :\t");
            int N=art.nextInt();
            x=N;
            y=N;

        }while(x<=0);
        int mini=1;
        int mn=y;
        int  gs=0;
        int maxi=1;
        for(int i=1; i<=x;i++)
        {
            if (mini>i){
                mini=i;
            }
            if(maxi<i){
                maxi=i;
               gs=maxi-1;
            }
        }
        int h=2;
        while(h<=y)
        {
            if (mn>h){
                mn=h;
            }
            h++;
        }
        int j=1;
        int somme=0;
        int ppremier=2;
       while(j<=x){
            int trouve=0;
           for (int  k=1 ;k<=j;k++)
           {
               if (j%k==0)
                {   
                    trouve++;
                }
            }
            if (trouve==2)
            {
                if(j<ppremier){
                ppremier=j;}       
                somme+=j;
            }
            j++;
        }int p=1;
        int a=1;
        int prod=1;  
        int mpf=0;
        for(p=1; p<=y;p++){
            int div=0;
            for (a=1;a<p; a++ ){
                if(p%a==0){
                    div+=a;
                }
            }
            if(div==p){
                mpf=p;
                if(mpf<p){
                    mpf=p;
                }
                prod*=p;
            }
        }
        System.out.println("La valeur la plus petite de la serie vaut: "+mini);
        System.out.println("La deuxieme valeur la plus petite de la serie vaut: "+mn);
        System.out.println("La valeur la plus grande de la serie vaut: "+maxi);
        System.out.println("La deuxieme valeur la plus grande de la serie vaut: "+gs);
        System.out.println("La somme des nombres premiers de la serie  vaut: "+somme);
        if(y<6){ System.out.println("Le produit des nombre parfaits de la serie est nul ");}
        else{ System.out.println("Le produit des nombre parfaits de la serie vaut: "+prod);}
        System.out.println("La valeur min premier  vaut: "+ppremier);
        System.out.println("La valeur max parfaite  vaut: "+mpf);
           

    }

}