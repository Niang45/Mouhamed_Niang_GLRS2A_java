import java.util.Scanner;
class Exo3SansClass{
    public static void main(String[] args)  {
        Scanner ok=new Scanner(System.in);
        int a=0;
        int m=0;
        int j=0;
        System.out.print("Entrer l'annee :\t");
        int an=ok.nextInt();
        System.out.print("Entrer le mois :\t");
        int mo=ok.nextInt();
        System.out.print("Entrer le jours :\t");
        int jo=ok.nextInt();
       if (an>0 && mo>=1 && mo<=12 && jo>=1 && jo<=31)
        {
            if((mo==4) || (mo==6) || (mo==9) || (mo==11))
            {
                j=30;
            }else
            {
                if(m==2)
                {
                    int d=((an%4==0 && an%100!=0 ) || (a%400==0))?29:28;
                    j=d;
                }else
                {
                    j=31;
                }    
            }
             System.out.println("La date saisie du "+jo+"-"+mo+"-"+an+" est valide" ); 
        }else{
            System.out.println("La date saisie est invalide" ); 
        }
    }
}