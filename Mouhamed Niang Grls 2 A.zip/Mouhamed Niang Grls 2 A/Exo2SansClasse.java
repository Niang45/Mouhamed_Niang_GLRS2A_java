import java.util.Scanner;
class Exo2SansClasse{
    public static void main(String[] args)
    {
        Scanner ok = new Scanner(System.in);
        /*
        Exercice 2 
        Saisir une année et un mois 
        puis determiner le nombre de jour de ce mois  dans l'année
        1- pas de classe de java 
        2- Faire avec les classes Java */
        int a=0;
        int m=0;
        int j=0;
       do{
            System.out.print("Entrer l'annee :\t");
            int an=ok.nextInt();
            System.out.print("Entrer le mois :\t");
            int mois=ok.nextInt();
            a=an;
            m=mois;
        }while(a<0 &&   12<m &&m<=0  );
        if((m==4) || (m==6) || (m==9) || (m==11)){
            j=30;
        }else{
            if(m==2){
                int d=((a%4==0 && a%100!=0 ) || (a%400==0))?29:28;//if else
                j=d;
            }else{
                j=31;
            }    
        }
        String mOnth=null;
        switch(m){
            case 1:
                mOnth="Janvier";
                System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
             case 2:
                 mOnth="Fevrier";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
             case 3:
                 mOnth="Mars";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
             case 4:
                 mOnth="Avril";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
             case 5:
                mOnth="Mai";
                System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
             case 6:
                 mOnth="Juin";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
            case 7:
                 mOnth="Juillet";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
            case 8:
                 mOnth="Aout";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
            case 9:
                 mOnth="Septembre";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
            case 10:
                 mOnth="Octobre";
                System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
            case 11:
                 mOnth="Juin";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
            case 12:
                 mOnth="Juin";
                 System.out.println("Le mois  de "+mOnth+" de l'annee "+a+" compte "+j+ " jours" ); 
                break;
            default:System.out.print("la date saisie est invalide");
                break;
        }
    }   
}