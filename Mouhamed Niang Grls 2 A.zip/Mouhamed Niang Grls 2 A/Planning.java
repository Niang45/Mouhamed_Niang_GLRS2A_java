import java.util.Scanner;
class Planning {
    public static void main(String[] args) {
        Scanner ok = new Scanner(System.in);
        int ms=0;
        int d=0;
        int mp=0;
        int jp=0;
        int ap=0;
        System.out.print("Entrer l'annee :\t");
        int a=ok.nextInt();
        System.out.print("Entrer le mois :\t");
        int m=ok.nextInt();
        System.out.print("Entrer le jour :\t");
        int j=ok.nextInt();
        boolean cond1=(m>=1 && m<=12 && j>=1 && j<=31 );
        boolean cond2= ((m==4 || m==6 || m==9 ||m==11 && j>0 && j<31 ))||(m==1|| m==3|| m==5 || m==7 || m==8 ||m==12 && j>=1 || j<=30 );
        if(cond1!=true || cond2!=true){       
            System.out.println("Error!!! la date saisie est invalide.");
        }else{
            if((m==4) || (m==6) || (m==9) || (m==11)){
                int day=(j<30 || 1<=j)?j+1:1 ;
                int msu=(j==30)?m+1:m;
                ms=msu;
                d=day;
                int ds=(j<30 && j>1)?j-1:30 ;
                jp=ds;
                int mpr=(j<30 && j>1)?m:m-1;
                mp=mpr;
                  System.out.println("La date precedante est :"+jp+"/"+mp+"/"+ap);
                System.out.print("La date suivante est :"+d+"/"+ms+"/"+a);
            }
            if((m==1)|| (m==3)|| (m==5) || (m==7) || (m==8) ||(m==12)){
                int days=(j<31 || j>1)?j+1:1;
                d=days;
                int msu=(j==31)?m+1:m;
                ms=msu;
                int ds=(j<=30 && 1<j)?j-1:30 ;
                jp=ds;
                int mpr=(j<=30 && 1<j)?m:m-1;
                int mpz=(m==1)?12:m-1;
                mp=mpz;
                mp=mpr;
                if(m==1 && j==1){
                    ap=a-1;
                    mp=12;
                }else{
                    ap=a;
                    mp=m;
                
                }
                System.out.println("La date precedante est :"+jp+"/"+mp+"/"+ap);
                System.out.print("La date suivante est :"+d+"/"+ms+"/"+a);
            }    
            if(m==12 && j==31){
                a+=1;
                ms=1;
                mp=m;
                d=1;
                jp=j-1;
                ap=a-1;
                  System.out.println("La date precedante est :"+jp+"/"+mp+"/"+ap);
                 System.out.print("La date suivante est :"+d+"/"+ms+"/"+a);
            }
          
        }
            
        int alpha=0;
        if(m==2){
            int b=((a%4==0 && a%100!=0 ) || (a%400==0))?29:28;
            alpha=b;        
            boolean y=(j>alpha);
            if(y==true){ 
                System.out.println("Error!!! la date saisie est invalide.");
            }else{
                j=alpha;
                if (j==29|| j==28){
                    jp=b-1;
                    d=1;
                    ms=m+1;
                    mp=m;
                    ap=a;
                    System.out.println("La date precedante est :"+jp+"/"+mp+"/"+ap);
                    System.out.print("La date suivante est :"+d+"/"+ms+"/"+a);
                }
            }    
        }         
    }    
}
