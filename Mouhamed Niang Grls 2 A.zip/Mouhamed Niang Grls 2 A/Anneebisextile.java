import java.util.Scanner;
class Anneebisextile{
    public static void main(String[] args)throws Exception{
        Scanner sc=new Scanner(System.in);
        /*
        Exercice 1:
        Saisir une année qui est un entier positif puis 
        determiner si l'année est bisextile ou pas 
        */
      
            System.out.print("entrer anne :\t");
            int N=sc.nextInt();
            while(N<=0){
                System.out.print("entrer anne :\t");
                int x=sc.nextInt();
                N=x;
            }
       
        if ((N%4==0 && N%100!=0 ) || N%400==0)
        {
            System.out.println("L'annee est " +N+ " bisextile");
        }else{
            System.out.println("L'annee n'est " +N+ " bisextile");
        }
        
    }
    
}